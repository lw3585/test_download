#!/bin/bash
APP_DIR=/app
APP_NAME=music_player
APP_BAK_NAME=music_player_bak
SERVER_IP=music.lingban.cn
PORT_NUM=25018
#CLIENT_ID=1
TIME_CNT=0

echo "start tc_port"
chmod 777 $APP_DIR/tc_port
killall tc_port
nohup $APP_DIR/tc_port > $APP_DIR/tc_port.log 2>$APP_DIR/tc_port.log &

rm -fr /var/run/wpa_supplicant/wlan0

while :
do 
    RES=$(cat /usr/app/client_id.dat)
    if [[ x$RES != x"" ]];then
        echo "get client id: $RES"
        CLIENT_ID=$RES
        break
    else
        echo "no client id........" 
        sleep 2   
    fi
done

#Before config the network, start the music_player first!!!
echo "start music player"
if [ -f $APP_DIR/log_music_player.logbak ];then
	rm -f $APP_DIR/log_music_player.logbak
	echo "removed log_music_player.logbak"
fi
if [ -f $APP_DIR/log_music_player.log ];then
	mv $APP_DIR/log_music_player.log $APP_DIR/log_music_player.logbak
        echo "log_music_player.log has overrided log_music_player.logbak"
fi

                          
if [ -f $APP_DIR/log_music_player_to_file.logbak ];then            
        rm -f $APP_DIR/log_music_player_to_file.logbak             
        echo "removed log_music_player_to_file.logbak"             
fi                                                         
if [ -f $APP_DIR/log_music_player_to_file.log ];then               
        mv $APP_DIR/log_music_player_to_file.log $APP_DIR/log_music_player_to_file.logbak
        echo "log_music_player_to_file.log has overrided log_music_player_to_file.logbak"
fi



if [ -f $APP_DIR/$APP_NAME ]; then
        chmod +x $APP_DIR/$APP_NAME
        nohup $APP_DIR/$APP_NAME $SERVER_IP $PORT_NUM $CLIENT_ID > $APP_DIR/log_music_player.log 2>$APP_DIR/log_music_player.log &
	echo "music_player is started!"
elif [ -f $APP_DIR/$APP_BAK_NAME ]; then
        cp $APP_DIR/$APP_BAK_NAME $APP_DIR/$APP_NAME 
        chmod +x $APP_DIR/$APP_NAME
        nohup $APP_DIR/$APP_NAME $SERVER_IP $PORT_NUM $CLIENT_ID > $APP_DIR/log_music_player.log 2>$APP_DIR/log_music_player.log &
	echo "music_player is started!"
else
        echo "can't find program music_player!"
        #download from the server
fi



sleep 10

echo ""
echo "***************************************************************"
echo "network.sh start"

let TIME_CNT=0
while :
do
WLAN0_DEVICE=$(ifconfig | grep "wlan0" | awk '{print $1}')
if [[ $WLAN0_DEVICE == "wlan0" ]]; then
	echo "===== wlan0 link up, start to config wlan0 via wap_supplicant"
	wpa_supplicant -B -i wlan0 -c /etc/wpa_supplicant.conf
	break
else
	sleep 1
	let TIME_CNT++
	if [ $TIME_CNT -gt 60 ]; then
		echo "Time out for wlan0 link up!"
	fi
	echo "can't detect wlan0, continue!"
	continue
fi
done

sleep 3

#let TIME_CNT=0
#while :
#do	
#DIAL_RES=$($APP_DIR/attest /dev/ttyUSB2 | grep "Close device and done the test")
#if [[ x$DIAL_RES != x"" ]];then
#	echo "4G dial success"
#	udhcpc -i usb0
#	udhcpc -i usb0
#	udhcpc -i usb0
#	break
#else
#	sleep 5
#	echo "4G dial failed, redial...."
#	let  TIME_CNT++
#	if [ $TIME_CNT -gt 5 ]; then
#		echo "Time out for 4G dial"
#	fi
#	echo "can't dial 4G, continue!"
#        continue
#fi
#done


#add DNS server
echo "nameserver 114.114.114.114" >> /etc/resolv.conf

ifconfig

echo "network.sh exit"
echo "***************************************************************"
