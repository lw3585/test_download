#!/bin/bash
APP_DIR=/app
APP_UPGRADE_DIR=/app/upgrade
APP_UPGRADE_PACKAGE_DIR=/app/upgrade/package
APP_BIN_TC_PORT=tc_port
APP_BIN_MP=music_player
SH_NETWORK=network.sh

DATE="`date +%Y-%m-%d,%H:%m:%s`" 

#TEST_DIR=/media/sf_ushare/test/upgrade
#TEST_PACK_DIR=/media/sf_ushare/test/upgrade/package

echo "upgrade start, version: v1.0. date: $DATE" >> $APP_UPGRADE_DIR/log.txt

# upgrade tc_port TODO: 备份
if [ -f $APP_DIR/$APP_BIN_TC_PORT ]&&[ -f $APP_UPGRADE_PACKAGE_DIR/$APP_BIN_TC_PORT ];then
	echo "start upgrade tc_port" >> $APP_UPGRADE_DIR/log.txt
	rm -f $APP_DIR/$APP_BIN_TC_PORT
	cp $APP_UPGRADE_PACKAGE_DIR/$APP_BIN_TC_PORT $APP_DIR/
	chmod 777 $APP_DIR/$APP_BIN_TC_PORT
fi

# upgrade music_player TODO: 备份
if [ -f $APP_DIR/$APP_BIN_MP ]&&[ -f $APP_UPGRADE_PACKAGE_DIR/$APP_BIN_MP ];then
	echo "start upgrade $APP_BIN_MP" >> $APP_UPGRADE_DIR/log.txt
	rm -f $APP_DIR/$APP_BIN_MP
	cp $APP_UPGRADE_PACKAGE_DIR/$APP_BIN_MP $APP_DIR/
	chmod 777 $APP_DIR/$APP_BIN_MP
fi

# upgrade network.sh TODO: 备份
if [ -f $APP_DIR/$SH_NETWORK ]&&[ -f $APP_UPGRADE_PACKAGE_DIR/$SH_NETWORK ];then
	echo "start upgrade $SH_NETWORK" >> $APP_UPGRADE_DIR/log.txt
	rm -f $APP_DIR/$SH_NETWORK
	cp $APP_UPGRADE_PACKAGE_DIR/$SH_NETWORK $APP_DIR/
	chmod 777 $APP_DIR/$SH_NETWORK
fi

echo "upgrade end" >> $APP_UPGRADE_DIR/log.txt
reboot
# for test
#echo "start upgrade tc_port" >> $APP_UPGRADE_DIR/log.txt
#cp $TEST_PACK_DIR/tc_port $TEST_DIR/
#echo "start upgrade music_player" >> /media/sf_ushare/test/upgrade/upgrade.log
#cp $TEST_PACK_DIR/music_player $TEST_DIR/


