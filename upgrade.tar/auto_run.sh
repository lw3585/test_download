#!/bin/bash



echo "start to upgrade" > ./upgrade.log

sleep 10;

echo "end to upgrade" >> ./upgrade.log
